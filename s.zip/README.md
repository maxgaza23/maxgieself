# LINE SELF BOT BY MAXGIE

## -> Installation

```sh
$ python -m pip install -r requirement.txt
$ python client.py
```

## -> Credit by @MaxGie
- `LINE ID: zaro_backbot.`

